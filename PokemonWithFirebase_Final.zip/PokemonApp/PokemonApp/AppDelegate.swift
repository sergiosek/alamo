//
//  AppDelegate.swift
//  PokemonApp
//
//  Created by Luis Rollon Gordo on 12/6/17.
//  Copyright © 2017 EfectoApple. All rights reserved.
//

import UIKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        return true
    }

}

